from setuptools import setup

setup(
    name="not_defteri",
    version="1.0",
    description='My package for testing',
    url='#',
    author="Ali Apaydin",
    author_email='apaydin.a@gmail.com',
    license='APAYDIN SOFTWORKS',
    packages=['not_defteri'],
    zip_safe=False
)