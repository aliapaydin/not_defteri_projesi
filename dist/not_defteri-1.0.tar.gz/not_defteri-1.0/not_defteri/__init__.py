from not_defteri import notlar

from not_defteri import kullanici